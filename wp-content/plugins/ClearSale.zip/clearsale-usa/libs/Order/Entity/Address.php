<?php

class Clearsale_Total_Model_Order_Entity_Address
{
	public $Street;
	public $City;
	public $State;
	public $ZipCode;
	public $County;
	public $Country;
	public $Number;
}

?>