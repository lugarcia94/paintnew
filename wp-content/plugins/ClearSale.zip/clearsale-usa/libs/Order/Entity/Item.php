<?php

class Clearsale_Total_Model_Order_Entity_Item
{
	public $ProductId;
	public $ProductTitle;
	public $Price;
	public $Category;
	public $Quantity;
}

?>
