<?php

class Clearsale_Total_Model_Order_Entity_Diagnostic
{
	public $order_id;
	public $clearsale_status;
	public $score;
	public $diagnostics;
	public $dt_sent;
	public $dt_update;
}

?>
