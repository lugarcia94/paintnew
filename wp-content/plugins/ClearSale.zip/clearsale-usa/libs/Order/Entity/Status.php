<?php

class Clearsale_Total_Model_Order_Entity_Status
{
	public $ID;
	public $Status;
	public $Score;
	
	function __construct() {
		$this->ID = "";
	}
}

?>

