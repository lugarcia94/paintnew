<?php

class Clearsale_Total_Model_Order_Entity_CustomField
{
	public $Type;
	public $Name;
	public $Value;

}

?>
