<?php

class Clearsale_Total_Model_Order_Entity_Payment
{
	public $Date;     
	public $Type;
	public $Gateway;
	public $CardNumber;
	public $CardHolderName;
	public $Amount;
	public $PaymentTypeID;
	public $CardBin;
}

?>


