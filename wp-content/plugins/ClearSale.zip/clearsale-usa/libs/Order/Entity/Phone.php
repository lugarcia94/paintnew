<?php

class Clearsale_Total_Model_Order_Entity_Phone
{
	public $Type;
	public $CountryCode;
	public $AreaCode;
	public $Number;
}

?>