<?php

class Clearsale_Total_Model_Auth_Entity_Credentials
{
	public $ApiKey;
	public $ClientID;
	public $ClientSecret;
	
}

?>