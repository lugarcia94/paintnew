<?php

class Clearsale_Total_Model_Auth_Entity_Token
{
	public $Value;
	public $ExpirationDate;
}   

?>
