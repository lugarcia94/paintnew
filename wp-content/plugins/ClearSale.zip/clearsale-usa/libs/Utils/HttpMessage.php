<?php

class Clearsale_Total_Model_Utils_HttpMessage
{
	public $HttpCode;
	public $HttpMessage;
	public $Body;

}